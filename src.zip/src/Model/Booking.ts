import { Room } from "./Room";
import { User } from "./User";

export class Booking {
    constructor(public id: number = 0, public room: Room, public user: User, public purpose: string = "", public participants: number = 0) {
    }
}
