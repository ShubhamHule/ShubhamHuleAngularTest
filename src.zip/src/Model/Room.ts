export class Room {
    constructor(public id: number = 0, public name: string = "") {
    }
}