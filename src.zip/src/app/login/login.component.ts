import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/Model/User';
import { UserServiceService } from '../Service/user-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  user: User = new User();
  users: User[] = [];
  msg: string = "";

  constructor(private service: UserServiceService, private router: Router) {
    this.loadUsers;
  }

  ngOnInit(): void {
  }

  Login() {
    let result = this.service.checkUser(this.user);
    if (result) {
      this.router.navigate(['Booking']);
    }
  }

  loadUsers() {
    this.service.getAllUsers();//subscribe((sucess: User[])=>this.users=sucess);
  }

  getUsers() {
    return this.users;
  }

}
