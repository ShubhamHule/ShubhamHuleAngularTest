import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { User } from 'src/Model/User';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private user: User[] = [];

  constructor() {
    let u1 = new User(1, "xyz@zensar.com", "123456");
    let u2 = new User(2, "mno@zensar.com", "123456");
    let u3 = new User(3, "def@zensar.com", "123456");
    this.user.push(u1);
    this.user.push(u2);
    this.user.push(u3);
  }

  getAllUsers() {
    return this.user
  }

  getUser(): Observable<User[]> {
    return of(this.user);
  }

  registerUser(user: User) {
    this.user.push(user);
  }

  checkUser(user: User): boolean {
    if (user.email === "abc@zensar.com" && user.password === "zensar") {
      return true;
    }
    return false;
  }

}
