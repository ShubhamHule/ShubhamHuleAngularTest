import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RoomServiceService {

  constructor() { }

  getAllRooms() {

  }

  addNewRoom() {

  }

}
